package hacs;

import java.util.ArrayList;


@SuppressWarnings("serial")
public class SolutionList extends ArrayList<Solution> {

	public SolutionList() {
	}
}