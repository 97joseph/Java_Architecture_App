package hacs;

import javax.swing.*;

@SuppressWarnings("serial")
public class SolutionMenu extends JDialog {

	public SolutionMenu() {
	}

	void showMenu(Solution theSolution) {
		setVisible(true);
	}

}
